<template>
    <div></div>
</template>

<script>
export default {
    name: 'ui-drawer'
}
</script>