export default function () {
    let props = {
        ustyle: Object,
        root: {
            typeof: Object,
            default: document.body
        },
    }
    return props
}