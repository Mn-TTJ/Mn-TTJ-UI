export default function () {
    let props = {
        target: Boolean,
        ustyle: Object
    }

    return props
}