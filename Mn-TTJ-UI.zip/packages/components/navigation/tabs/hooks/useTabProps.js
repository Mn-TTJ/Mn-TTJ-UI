export default function () {
    let props = {
        active: {
            default: 0,
            type: Number
        },
        height: String,
        width: String
    }
    return props
}