export default function () {
    let props = {
        label: {
            type: String,
            default: ''
        }
    }
    return props
}