import { computed, provide, reactive, ref } from "vue"
import { menuKey } from "../symbol"

export default function (props) {

    const isCollapse = ref(true)
    const collapseModel = computed(() => props.collapse && props.vertical)

    const menu = reactive({
        'menu': true,
        'menu-reverse': computed(() => props.left && !props.vertical),
        'menu-vertical': computed(() => props.vertical),
        'no-bottom': computed(() => props.noBorder),
        'menu-collapse': computed(() => isCollapse.value && collapseModel.value)
    })

    const menuBtns = reactive({
        'menu-btns': true,
        'menu-btns-reverse': computed(() => props.left && !props.vertical),
        'menu-btns-vertical': computed(() => props.vertical),
        'menu-btns-center': computed(() => !collapseModel.value && props.vertical && props.center)
    })

    const menuTitle = reactive({
        'menu-title': true,
        'menu-title-center': computed(() => !collapseModel.value && props.vertical && props.center)
    })

    const dark = {
        '--menu-bg-color': '#545c64',
        '--menu-text-color': 'white',
        '--menu-hover-color': '#434a50',
        '--menu-active-color': '#ffd04b'
    }

    const costom = reactive({
        '--menu-bg-color': computed(() => props.bgColor),
        '--menu-text-color': computed(() => props.textColor),
        '--menu-hover-color': computed(() => props.hoverColor),
        '--menu-active-color': computed(() => props.activeColor),
    })

    const uStyle = computed(() => {
        if (props.dark) return dark
        else return costom
    })

    const callCollapse = () => {
        isCollapse.value = !isCollapse.value
    }

    provide(menuKey, {
        vertical: computed(() => props.vertical),
        collapseModel,
        isCollapse,
        center: computed(() => props.center)
    })

    return { menu, menuBtns, menuTitle, uStyle, callCollapse }
}