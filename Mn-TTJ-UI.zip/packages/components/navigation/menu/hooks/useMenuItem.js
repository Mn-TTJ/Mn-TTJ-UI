import { computed, inject, reactive } from "vue";
import { menuKey } from "../symbol";

export default function (props) {

    const injectProps = inject(menuKey)

    const collapseModel = injectProps.collapseModel

    const isCollapse = injectProps.isCollapse

    const menuItem = reactive({
        'menu-item': true,
        'menu-item-vertical': injectProps.vertical,
        'menu-item-isCollapse': computed(() => collapseModel.value && isCollapse.value),
        'menu-item-unCollapse': computed(() => collapseModel.value && !isCollapse.value),
        'menu-item-center': computed(() => !collapseModel.value && injectProps.center.value),
        'menu-disabled': computed(() => props.disabled)
    })

    return { menuItem, collapseModel, isCollapse }
}