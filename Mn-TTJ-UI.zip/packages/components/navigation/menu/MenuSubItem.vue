<template>
    <div class="menu-subItem-root">
        <div ref="shower">
            <MenuItem :label="label">
            </MenuItem>
        </div>
        <div class="menu-subItem" ref="panel" v-show="isOnPanel">
            <slot></slot>
        </div>
    </div>
</template>

<script>
import { subItemProps } from './props'
import MenuItem from './MenuItem.vue'
import { ref } from 'vue';
import useMenuSubItem from './hooks/useMenuSubItem';
export default {
    name: 'ui-menu-sub-item',
    components: { MenuItem }
}
</script>

<script setup>
// eslint-disable-next-line
const props = defineProps(subItemProps);
const shower = ref(null)
const panel = ref(null)
const { isOnPanel } = useMenuSubItem(props, shower, panel)
</script>

<style lang="scss" scoped>
@import '../../../css/main.css';
@import './css/menuSubItem.scss';
</style>