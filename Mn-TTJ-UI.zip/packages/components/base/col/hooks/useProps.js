export default function () {
    return {
        colCount: Number, // 列数
        offset: Number, // 偏移量 
        xl: Number,   //超大屏 >1920px
        lg: Number, // >1200px
        md: Number, // >992px
        sm: Number, // >768px
        xs: Number, //<768px
    }
}