export default function () {
    let props = {
        underline: Boolean,
        disabled: Boolean,
        href: String,
        color:String,
    }
    return props;
} 