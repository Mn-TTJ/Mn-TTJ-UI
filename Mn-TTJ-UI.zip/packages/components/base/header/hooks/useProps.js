export default function () {
    let props = {
        height: String,
        bgc: String,
        
    }
    return props
}