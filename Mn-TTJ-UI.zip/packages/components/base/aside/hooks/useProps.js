export default function () {
    return {
        width:String,
        bgc: String,
    }
}