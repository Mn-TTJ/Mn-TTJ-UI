export default function () {
    return {
        height: String,   //固定高度，超出则滚动
        maxHeight: Number, //最大高度，超过之后才会显示滚动条
        color: String,
        
    }
}