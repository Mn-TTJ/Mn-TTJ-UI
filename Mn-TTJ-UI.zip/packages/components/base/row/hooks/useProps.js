export default function () {
    return {
        gutter: Number,
        justify:String
    }
}