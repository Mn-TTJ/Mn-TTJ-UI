export default function () {
    return {
        bgc: String,
        height: Number,
    }
}