export default function () {
    return {
        height: String,
        bgc:String,
    }
}