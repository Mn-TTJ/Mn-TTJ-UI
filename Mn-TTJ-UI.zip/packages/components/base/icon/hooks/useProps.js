export default function () {
    return {
        icon: String,
        size:String,
        color:String,// 图标颜色
    }
}