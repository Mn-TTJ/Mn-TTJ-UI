export default function () {
    let props = {
        name: String,
        show: Boolean,
        disabled: Boolean,
        modelValue: String,
    }
    return props
}