export default function () {
    let props = {
        name: String,
        modelValue: String,
        dataSet: Array,
        multiple: Boolean,
        uStyle: Object,
        shower: Boolean,
        panel: Boolean,
        lazy: Boolean,
        callBack: Function,
        disabled: Boolean,
    }
    return props
}