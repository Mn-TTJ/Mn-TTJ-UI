export default function () {
    let props = {
        name: String,
        modelValue: String,
        week: Boolean,
        disabled: Boolean
    }
    return props
}