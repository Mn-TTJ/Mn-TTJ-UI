const WEEK = ['SUN', 'MON', 'TUES', 'WED', 'THUR', 'FRI', 'SAT']
const MONTH = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEPT', 'OCT', 'NOV', 'DEC']
export { WEEK, MONTH }