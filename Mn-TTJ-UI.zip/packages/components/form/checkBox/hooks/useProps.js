export default function () {
    let props = {
        name: String,
        labels: Array,
        modelValue: Array,
        all: Boolean,
        hasBorder: Boolean,
        disabled: Boolean
    }
    return props
}