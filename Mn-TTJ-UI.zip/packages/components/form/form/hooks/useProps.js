export default function () {
    let props = {
        style: Object,
    }
    return props
}