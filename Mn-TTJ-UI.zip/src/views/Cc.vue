<template>
    <div>hello</div>
    <ui-breadcrumb useName :start="2"></ui-breadcrumb>
</template>

<script setup>
</script>
