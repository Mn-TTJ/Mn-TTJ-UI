<template>
  <div>
    <ui-menu :active="1" ref="menu">
      <template #title>
        <p>title</p>
      </template>
      <ui-menu-item label="biaoti" disabled>
        <template #icon>
          <p>&#xe69e;</p>
        </template>
      </ui-menu-item>
      <ui-menu-item label="biaoti2"></ui-menu-item>
      <ui-menu-sub-item label="biaoti3">
        <ui-menu-item label="biaoti" disabled>
          <template #icon>
            <p>&#xe69e;</p>
          </template>
        </ui-menu-item>
        <ui-menu-item label="biaoti2"></ui-menu-item>
      </ui-menu-sub-item>
    </ui-menu>
  </div>
  <button @click="a">a</button>
</template>

<script setup>
import { ref } from 'vue';

const menu = ref(null)

const a = () => {
  menu.value.callCollapse()
}
</script>

<style lang="scss" scoped>
div {
  height: 100%;
}
</style>